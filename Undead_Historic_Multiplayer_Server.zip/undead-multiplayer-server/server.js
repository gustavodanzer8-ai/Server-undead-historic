'use strict';
const http = require('http');
const { WebSocketServer, WebSocket } = require('ws');
const PORT = Number(process.env.PORT || 10000);
const rooms = new Map();
const clients = new Map();
const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

function makeCode() {
  let code;
  do {
    code = Array.from({ length: 6 }, () => CODE_CHARS[Math.floor(Math.random() * CODE_CHARS.length)]).join('');
  } while (rooms.has(code));
  return code;
}
function send(ws, data) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data));
}
function roomBroadcast(room, data, except) {
  for (const peer of room.players) if (peer !== except) send(peer, data);
}
function leave(ws) {
  const info = clients.get(ws);
  if (!info) return;
  clients.delete(ws);
  const room = rooms.get(info.code);
  if (!room) return;
  room.players.delete(ws);
  roomBroadcast(room, { type: 'peer-left' });
  if (room.players.size === 0) rooms.delete(info.code);
  else {
    const remaining = [...room.players][0];
    send(remaining, { type: 'room-status', code: info.code, players: room.players.size, host: true });
  }
}

const server = http.createServer((req, res) => {
  if (req.url === '/health' || req.url === '/') {
    res.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
    res.end(JSON.stringify({ ok: true, service: 'Undead Historic Multiplayer', rooms: rooms.size }));
    return;
  }
  res.writeHead(404); res.end('Not found');
});
const wss = new WebSocketServer({ server, maxPayload: 16 * 1024 });
wss.on('connection', (ws) => {
  let lastMessage = 0;
  ws.on('message', (raw) => {
    const now = Date.now();
    if (now - lastMessage < 25) return; // limite simples contra excesso de mensagens
    lastMessage = now;
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { send(ws, { type: 'error', message: 'Mensagem invalida.' }); return; }

    if (msg.type === 'create-room') {
      if (clients.has(ws)) return;
      const code = makeCode();
      const room = { players: new Set([ws]), createdAt: now };
      rooms.set(code, room); clients.set(ws, { code, playerId: 1 });
      send(ws, { type: 'room-created', code, playerId: 1, players: 1 });
      return;
    }
    if (msg.type === 'join-room') {
      if (clients.has(ws)) return;
      const code = String(msg.code || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6);
      const room = rooms.get(code);
      if (!room) { send(ws, { type: 'error', message: 'Sala nao encontrada. Confira o codigo.' }); return; }
      if (room.players.size >= 2) { send(ws, { type: 'error', message: 'Essa sala ja esta cheia.' }); return; }
      room.players.add(ws); clients.set(ws, { code, playerId: 2 });
      send(ws, { type: 'room-joined', code, playerId: 2, players: 2 });
      roomBroadcast(room, { type: 'peer-joined', players: 2 }, ws);
      return;
    }

    const info = clients.get(ws);
    if (!info) { send(ws, { type: 'error', message: 'Crie ou entre em uma sala primeiro.' }); return; }
    const room = rooms.get(info.code);
    if (!room) { leave(ws); return; }

    // Canal de sincronizacao: retransmite somente dados pequenos e validados.
    if (msg.type === 'player-state') {
      const p = msg.state || {};
      const state = {
        x: Number.isFinite(p.x) ? Math.max(-100000, Math.min(100000, p.x)) : 0,
        y: Number.isFinite(p.y) ? Math.max(-100000, Math.min(100000, p.y)) : 0,
        z: Number.isFinite(p.z) ? Math.max(-5000, Math.min(5000, p.z)) : 0,
        face: p.face === -1 ? -1 : 1,
        state: typeof p.state === 'string' ? p.state.slice(0, 16) : 'idle',
        t: Number.isFinite(p.t) ? Math.max(0, Math.min(60, p.t)) : 0,
        scene: typeof p.scene === 'string' ? p.scene.slice(0, 24) : 'city',
        hp: Number.isFinite(p.hp) ? Math.max(0, Math.min(100, p.hp)) : 100
      };
      roomBroadcast(room, { type: 'peer-state', playerId: info.playerId, state }, ws);
    }
    if (msg.type === 'ping') send(ws, { type: 'pong', at: now });
  });
  ws.on('close', () => leave(ws));
  ws.on('error', () => leave(ws));
});
server.listen(PORT, '0.0.0.0', () => console.log(`Undead Historic Multiplayer listening on ${PORT}`));
